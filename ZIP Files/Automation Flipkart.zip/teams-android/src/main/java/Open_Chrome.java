
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Open_Chrome {

	// Creating a driver object referencing WebDriver interface
	static WebDriver driver_Chrome;

	//Method created for setting explicit wait of 10 seconds on desired element
	static void waitForElement(WebDriver driver01, String locator01) {
		WebDriverWait wait_Explicit = new WebDriverWait(driver01, 10);
		wait_Explicit.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator01)));
		
	}	
	
	public static void main(String[] args) throws InterruptedException {

		// Setting the webdriver.chrome.driver property to its executable's location
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Desktop\\chromedriver.exe");

		// Instantiating driver object
		driver_Chrome = new ChromeDriver();

		// Setting implicit wait time
		// driver_Chrome.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Using get() method to open a webpage
		driver_Chrome.get("https://www.flipkart.com");

		// Get the Web Element corresponding to the Enter Email text field
		// wait_Explicit.until(ExpectedConditions.visibilityOfElementLocated(By.className("_1fqY3P")));
		WebElement userName = driver_Chrome.findElement(By.xpath("(//input[@type='text'])[2]"));

		// Get the Web Element corresponding to the Enter Password text field
		WebElement password = driver_Chrome.findElement(By.xpath("//input[@type='password']"));

		userName.sendKeys("9339067488");
		password.sendKeys("Ajay@2901");

		// userName.clear();
		// password.clear();

		// userName.sendKeys("9339067488");
		// password.sendKeys("Ajay@2901");

		WebElement login_Button = driver_Chrome.findElement(By.xpath("(//span[text()='Login'])[2]"));
		login_Button.click();
		
		//Calling method created for explicit wait on the element
		waitForElement(driver_Chrome, "//span[text()='Sell On Flipkart']");
		WebElement searchInput = driver_Chrome
				.findElement(By.xpath("//input[@title='Search for products, brands and more']"));
		searchInput.sendKeys("arsenal");
		// searchInput.sendKeys(Keys.ENTER);

		WebElement searchButton = driver_Chrome.findElement(By.xpath("//button[@type='submit']"));
		searchButton.click();

		waitForElement(driver_Chrome, "//a[@title='Sports Men Round Neck Red T-Shirt']");
		WebElement select_Product = driver_Chrome
				.findElement(By.xpath("//a[@title='Sports Men Round Neck Red T-Shirt']"));
		select_Product.click();

		//String[] currentWindowsList = driver_Chrome.getWindowHandles();
		//driver_Chrome.switchTo().window(currentWindow);
		
		//waitForElement(driver_Chrome, "//li[@id='swatch-1-size']//a");
		WebElement select_Size = driver_Chrome.findElement(By.xpath("//li[@id='swatch-1-size']//a"));
		select_Size.click();

		// WebElement addToCart =
		// driver_Chrome.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[1]/div[1]/div[2]/div/ul/li[1]/button"));
		// addToCart.click();

		// WebElement placeOrder =
		// driver_Chrome.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div[1]/div/div[3]/div/form/button/span"));
		// placeOrder.click();

		// WebElement deliveryAddress =
		// driver_Chrome.findElement(By.xpath("/html/body/div/div/div[2]/div/div[1]/div[2]/div/div/div/div[1]/label[1]/div[2]/div/div[1]/button"));
		// deliveryAddress.click();

		// WebElement orderSummaryContinue =
		// driver_Chrome.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div[3]/div/div/div/div[2]/div[3]/span[2]/button"));
		// orderSummaryContinue.click();

		// Closing the browser
		// driver_Chrome.quit();
	}

}
